 //can_rx.c
#include "can_def.c"
#include "header.h"
int main()
{
CAN2_MSG m1;
	LCD_CONFIGURE();
	CAN2_init();

	while(1)
	{
	CAN2_RX1(&m1);
	
			REC_VALUE = m1.byteA;
			Vout = (((REC_VALUE*5)/4096)*10);
           Rs=((Rl*(Vcc-Vout))/Vout);

		  LCD_CMD(0x01);
       LCD_CMD(0x80);
			LCD_FLOAT(Rs);
			LCD_CMD(0xc0);
		LCD_STRING("TEMP VALUE...");
}

}

