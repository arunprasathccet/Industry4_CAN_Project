//can_def.c
#include <lpc21xx.h>
#include "header.h"

void CAN2_init(void)
{
PINSEL1 |= 0x14000;//p0.23 as RD2 and p0.24 as TD2
VPBDIV = 1;//PCLK as 60MHZ 
C2MOD = 0x1;//CAN2 into reset mode
	AFMR = 0x2;//Enable acceptance filter
C2BTR = 0x001C001D;//PCLK as 60MHZ with Bitrate as 125kbps	

C2MOD = 0x00;//CAN2 into normal mode
}

void CAN2_RX1(CAN2_MSG*m1)
		{
	while((C2GSR&(1<<0))==0);
	m1->id=C2RID;
	m1->dlc=(C2RFS>>16)&0xF;
	m1->rtr=(C2RFS>>30)&0x1;
	if(m1->rtr==0)
		{ //if data frame
		m1->byteA=C2RDA;
		m1->byteB=C2RDB;
	}
	C2CMR=(1<<2);//free receiver buffer(imp)
}


void delay_ms(u32 ms)
{
T0PR=60000-1;
	T0TCR=0x1;
	while(T0TC<ms);
	T0TCR = 0x03;
	T0TCR=0x0;
}


void delay_milliseconds(int ms)


{


	T0PR=15000-1;


	T0TCR= 0X01;


	while(T0TC<ms);


	T0TCR = 0x03;


	T0TCR = 0x00;


}



void LCD_STRING(unsigned char *s)

{

	char pos=0;

	while(*s)

	{

	  LCD_DATA(*s++);

		pos++;

		if(pos==16)

			LCD_CMD(0xc0);

	}

}



void LCD_CONFIGURE(void)

{

  IODIR1 = LCD_D|RS|RW|EN;	//P0.0 to P0.9 as OUTPUT pins

	LCD_CMD(0X01);//To clear the display

	LCD_CMD(0X02);//Return cursor to home position

	LCD_CMD(0X02);//Return cursor to home position

	LCD_CMD(0X28);//4BIT INTERFACE MODE WITH BOTH LINES

	

	LCD_CMD(0X0C);//DISPLAY ON CURSOR OFF

	LCD_CMD(0X80);//SELECT STARTING ADDRESS OF DDRAM

}



void LCD_CMD(unsigned char cmd)

{

	IOCLR1 = LCD_D;

	IOSET1 = (cmd&0xf0)<<16;//assigning command to the data pins

	IOCLR1 = RS;//command register is selected

	IOCLR1 = RW;

	IOSET1 = EN;//latch the data to the LCD

	delay_milliseconds(2);//wait for 2ms because LCD is in internal 

	                      // operation mode

	IOCLR1 = EN;//To re-latch the next byte

	

	IOCLR1 = LCD_D;

	IOSET1 = (cmd&0x0F)<<20;//assigning command to the data pins

	IOCLR1 = RS;//command register is selected

  IOCLR1 = RW;	

	IOSET1 = EN;//latch the data to the LCD

	delay_milliseconds(2);//wait for 2ms because LCD is in internal 

	                      // operation mode

	IOCLR1 = EN;//To re-latch the next byte

}

void LCD_DATA(unsigned char d)

{

	IOCLR1 = LCD_D;

	IOSET1 = (d&0xf0)<<16;//assigning command to the data pins

	IOSET1 = RS;//data register is selected

	IOCLR1 = RW;

	IOSET1 = EN;//latch the data to the LCD

	delay_milliseconds(2);//wait for 2ms because LCD is in internal 

	                      // operation mode

	IOCLR1 = EN;//To re-latch the next byte

	

	IOCLR1 = LCD_D;

	IOSET1 = (d&0x0F)<<20;//assigning command to the data pins

	IOSET1 = RS;//command register is selected

	IOCLR1 = RW;

	IOSET1 = EN;//latch the data to the LCD

	delay_milliseconds(2);//wait for 2ms because LCD is in internal 

	                      // operation mode

	IOCLR1 = EN;//To re-latch the next byte

}



void LCD_INTEGER(int n)

{

	char arr[5];

	int i=0;

	if(n==0)

	{

		LCD_DATA('0');

  }

	else

	{	

		if(n<0)

		{

			LCD_DATA('-');

			n=-n;

    }

	 while(n>0)

	 {

		 arr[i++] = n%10;

		 n=n/10;

   }

	 for(i=i-1;i>=0;i--)

	   LCD_DATA(arr[i]+48);

  }

}

void LCD_FLOAT(float f)

{

 int temp;

 temp=f;

 LCD_INTEGER(temp);

 LCD_DATA('.');

 temp=(f-temp)*100;

 LCD_INTEGER(temp);	

}

//******************************************************************************\\

