	   //header.h/
#ifndef _HEADER_H
#define _HEADER_H


#define LCD_D 0xf<<20
#define RS 1<<17
#define RW 1<<18
#define EN 1<<19
typedef unsigned int u32;
typedef unsigned char u8;
 int REC_VALUE;
 float Rs,Rl=20000,Vout,Vcc=5,R0=1.4;

typedef struct CAN
{
u32 id;
u32 dlc;
u32	rtr;
u32 byteA;
u32 byteB;
}CAN2_MSG;


void CAN2_init(void);
void CAN2_TX1(CAN2_MSG);
void delay_ms(u32);
void CAN2_RX1(CAN2_MSG*);
void delay_mis(int mis);
void LCD_CONFIGURE(void);
void LCD_DATA(unsigned char);
void LCD_CMD(unsigned char);
void LCD_INTEGER(int);
void LCD_FLOAT(float);
void LCD_STRING(unsigned char*);




#endif


