//header.h/
#ifndef _HEADER_H
#define _HEADER_H
#define CS 1<<1
#define LCD_D 0xf<<20
#define RS 1<<17
#define RW 1<<18
#define EN 1<<19
#define FL_REG 7
#define MAS_EN (1<<5)
#define SPI_MODE3 (3<<3)
#define CLK 60000000
#define PCLK (CLK/4)
#define SPI_SPEED 100000
#define LOADVAL (PCLK/SPI_SPEED)
typedef unsigned int u32;
typedef unsigned char u8;
float Rs,Rl=20000,Vcc=5,Vout;
unsigned int sensor_val;
typedef struct CAN
{
u32 id;
u32 dlc;
u32	rtr;
u32 byteA;
u32 byteB;
}CAN2_MSG;

void configure_spi(void);
int SPI_write_with_read(unsigned char);
unsigned char SPI_MASTER(unsigned char);
void CAN2_init(void);
void CAN2_TX1(CAN2_MSG);
void delay_ms(u32);
void CAN_RX1(CAN2_MSG*);
void delay_milliseconds(int mis);
void LCD_CONFIGURE(void);
void LCD_DATA(unsigned char);
void LCD_CMD(unsigned char);
void LCD_INTEGER(int);
void LCD_FLOAT(float);
void LCD_STRING(unsigned char*);

#endif
