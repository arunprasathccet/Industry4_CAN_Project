main.o: main.c
main.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
main.o: mq3gas.c
main.o: defines.h
