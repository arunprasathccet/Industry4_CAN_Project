mq3gas.o: mq3gas.c
mq3gas.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
mq3gas.o: lcd_driver.c
