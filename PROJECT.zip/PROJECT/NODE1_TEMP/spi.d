spi.o: spi.c
spi.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
spi.o: C:\KeilARM\ARM\RV31\INC\stdio.h
spi.o: lcd_driver.c
