 #include <lpc21xx.h>
#include <stdio.h>
#include "lcd_driver.c"
#define CS 1<<1
#define FL_REG 7
#define MAS_EN 1<<5
#define SPI_MODE3 3<<3
#define CLK 60000000
#define PCLK CLK/4
#define SPI_SPEED 100000
#define LOADVAL PCLK/SPI_SPEED
void configure_spi(void);
float SPI_write_with_read(unsigned char);
unsigned char SPI_MASTER(unsigned char);
int main()
{
	unsigned char s[20] = "MCP3204--";
float f;
	configure_spi();
	LCD_CONFIGURE();
	IOSET0 |= CS;//Every time initially chip is deselected
	LCD_STRING(s);
	while(1)
	{
	f = SPI_write_with_read(0x00);
		delay_ms(1000);
	

	LCD_CMD(0xc0);
	LCD_FLOAT(f);
	}
	}
void configure_spi()
{
PINSEL0 |= 0x1500;//To select p0.4 as SCL,p0.5 as MISO,p0.6 as MOSI
S0SPCCR = LOADVAL;//setting the speed as 100kbps
S0SPCR = (MAS_EN)|(SPI_MODE3);//selecting master mode with spi_mode3 for clock polarity and phase
IODIR0 |= CS;//selecting the direction of chip selection pin
}
float SPI_write_with_read(unsigned char channel)
{
	unsigned int adcval;
	unsigned char lbyte,hbyte;
IOCLR0 |= CS;//Selecting the slave using the chip selection line
SPI_MASTER(0x6);//Start condition with single ended output
hbyte = SPI_MASTER(channel);//channel 1 is selected in the ADC
lbyte = SPI_MASTER(0x00);
	IOSET0 |= CS;//deselecting the slave 
adcval = (((hbyte&0x0f)<<8)|(lbyte));
	return ((adcval*3.3)/4096);
}
unsigned char SPI_MASTER(unsigned char data)
{
unsigned char 	temp = S0SPSR;//By reading the status register the flag will be cleared
	S0SPDR = data;//Giving the data  for the transmission
	while(((S0SPSR>>FL_REG)&1)==0);//wait for the transmission complete
return S0SPDR;	

}
