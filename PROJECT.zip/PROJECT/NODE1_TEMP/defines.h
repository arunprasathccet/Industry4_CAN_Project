//header.h/
#ifndef _HEADER_H
#define _HEADER_H

#define LCD_D 0xff00
#define En 1<<16
#define Rs 1<<17
#define CS (1<<7)
#define FL_REG 7
#define MAS_EN (1<<5)
#define SPI_MODE3 (3<<3)
#define CLK 60000000
#define PCLK (CLK/4)
#define SPI_SPEED 100000
#define LOADVAL (PCLK/SPI_SPEED)
typedef unsigned int u32;
typedef unsigned char u8;


	float f;
int sensor_val;
typedef struct CAN
{
u32 id;
u32 dlc;
u32	rtr;
u32 byteA;
u32 byteB;
}CAN2_MSG;

void configure_spi(void);
int SPI_write_with_read(unsigned char);
unsigned char SPI_MASTER(unsigned char);
void CAN2_init(void);
void CAN2_TX1(CAN2_MSG);
void delay_ms(u32);
void CAN_RX1(CAN2_MSG*);
void delay_mis(int mis);
void LCD_CONFIGURE(void);
void LCD_DATA(unsigned char);
void LCD_CMD(unsigned char);
void LCD_INTEGER(int);
void LCD_FLOAT(float);
void LCD_STRING(unsigned char*);

#endif
