

//can_tx.c
#include<lpc21xx.h>
#include "can_def.c"
#include "defines.h"

int main()
{
CAN2_MSG m1;

	LCD_CONFIGURE();
	configure_spi();
	LCD_STRING("SENSOR_VALUE.....");
  CAN2_init();
m1.id = 0x1;//random message id
m1.rtr = 0x0;//data frame
m1.dlc = 0x4;//sending only  4 bytes of data
//m1.byteA = 0xaabbccdd;//first four bytes of data	

while(1)
{
	
//Sending data 

	sensor_val =  SPI_write_with_read(0x00);
	delay_mis(1000);
	f = (((sensor_val*3.3)/4096));
	LCD_CMD(0xc0);
	LCD_FLOAT(f);
m1.byteA = sensor_val;
m1.byteB = 0x00;	//second four bytes  of data
CAN2_TX1(m1);//data frame transmission
delay_ms(1000);	
	
}	
}
