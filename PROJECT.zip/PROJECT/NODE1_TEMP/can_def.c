//can_def.c
#include "defines.h"
void CAN2_init(void)
{
PINSEL1 |= 0x14000;//p0.23 as RD2 and p0.24 as TD2
VPBDIV = 1;//PCLK as 60MHZ 
C2MOD = 0x1;//CAN2 into reset mode
AFMR = 0x2;//Accept all received message
C2BTR = 0x001C001D;//PCLK as 60MHZ with Bitrate as 125kbps	
C2MOD = 0x00;//CAN2 into normal mode
}



void CAN2_TX1(CAN2_MSG m1)
{
  C2TID1=m1.id;
	C2TFI1=(m1.dlc<<16);	
	if(m1.rtr==0) //if data frame
	{
		C2TFI1&=~(1<<30);//RTR=0
		C2TDA1=m1.byteA; //lower 4bytes of data
		C2TDB1=m1.byteB; //upper 4bytes of data
	}
	else
          {
		C2TFI1|=(1<<30); //RTR=1
	}
	C2CMR=(1<<0)|(1<<5);//Start Xmission & select Tx Buf1
	while((C2GSR&(1<<3))==0);//wait for data Xmission.
}


void delay_ms(u32 ms)
{
T0PR=60000-1;
	T0TCR=0x1;
	while(T0TC<ms);
	T0TCR = 0x03;
	T0TCR=0x0;
}
void configure_spi()
{
PINSEL0 |= 0x1500;//To select p0.4 as SCL,p0.5 as MISO,p0.6 as MOSI
S0SPCCR = LOADVAL;//setting the speed as 100kbps
S0SPCR = (MAS_EN)|(SPI_MODE3);//selecting master mode with spi_mode3 for clock polarity and phase
IODIR0 |= CS;//selecting the direction of chip selection pin
}
int SPI_write_with_read(unsigned char channel)
{
	
	unsigned int adcval;
	unsigned char lbyte,hbyte;
IOCLR0 |= CS;//Selecting the slave using the chip selection line
	SPI_MASTER(0x6);//Start condition with single ended output
hbyte = SPI_MASTER(channel);//channel 1 is selected in the ADC
lbyte = SPI_MASTER(0x00);
	IOSET0 |= CS;//deselecting the slave 
adcval = (((hbyte&0x0f)<<8)|(lbyte));
	
	return adcval;
}
unsigned char SPI_MASTER(unsigned char data)
{

unsigned char	temp = S0SPSR;//By reading the status register the flag will be cleared
	S0SPDR = data;//Giving the data  for the transmission
	while(((S0SPSR>>FL_REG)&1)==0);//wait for the transmission complete
return S0SPDR;	

}


void delay_mis(int mis)
{
	T0PR = 15000-1;
T0TCR = 0x01;
	while(T0TC<mis);
	T0TCR = 0x03;
	T0TCR = 0x00;
}
void LCD_CMD(unsigned char cmd)
{
	IOCLR0 = LCD_D;
	IOSET0 = cmd<<8;
	IOCLR0 = Rs;
	IOSET0 = En;
	delay_mis(2);
	IOCLR0 = En;
}


void LCD_CONFIGURE(void)
{
IODIR0 |= LCD_D|Rs|En;
LCD_CMD(0x01);
LCD_CMD(0x02);
LCD_CMD(0x38);
LCD_CMD(0x0c);
LCD_CMD(0x80);
	
}


void LCD_DATA(unsigned char d)
{
IOCLR0 = LCD_D;
IOSET0 = d<<8;
IOSET0 = Rs;
IOSET0 = En;
delay_mis(2);
IOCLR0 = En;
}
void LCD_STRING(unsigned char*s)
{
while(*s)
LCD_DATA(*s++);
}

void LCD_INTEGER(int n)
{
	char arr[20];
	int i=0;
	if(n==0)
	{
		LCD_DATA('0');
  }
	else
	{	
		if(n<0)
		{
			LCD_DATA('-');
			n=-n;
    }
	 while(n>0)
	 {
		 arr[i++] = n%10;
		 n=n/10;
   }
	 for(i=i-1;i>=0;i--)
	   LCD_DATA(arr[i]+48);
  }
}
void LCD_FLOAT(float f)
{
 int temp;
 temp=f;
 LCD_INTEGER(temp);
 LCD_DATA('.');
 temp=(f-temp)*100;
 LCD_INTEGER(temp);	
}
//******************************************************************************\\

