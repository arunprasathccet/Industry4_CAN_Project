can_tx.o: can_tx.c
can_tx.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
can_tx.o: can_def.c
can_tx.o: defines.h
