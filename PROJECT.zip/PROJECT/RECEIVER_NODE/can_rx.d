can_rx.o: can_rx.c
can_rx.o: can_def.c
can_rx.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
can_rx.o: defines.h
