//can_rx.c	

#include "can_def.c"
#include "defines.h"
int main()
{
    CAN2_MSG can_msg;
    float voltage;
	   LCD_INIT();
    CAN2_init();
  

    while (1)
    {
	    //LCD_STR("TEMP:");
        CAN2_RX1(&can_msg);

        if (can_msg.rtr == 0)
        {
            LCD_COMMAND(0x01); // Clear screen
            LCD_COMMAND(0x80); // Set cursor to start

            LCD_STR("CAN Msg Received");
            LCD_COMMAND(0xC0); // Move to second line

            voltage = ((can_msg.byteA & 0xFFF) * 3.3) / 4096.0;
            LCD_FLOAT(voltage);
        }

        delay_mis(500); // Optional delay to avoid LCD flicker
    }

    
}





