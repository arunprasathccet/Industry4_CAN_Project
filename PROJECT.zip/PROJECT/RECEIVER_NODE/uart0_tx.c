#include <lpc21xx.h>
#include <stdio.h>
#include "defines.h"
void uart0_init(void)
{
PINSEL0 |= 0x5;
U0LCR = 0x83;
U0DLL = 97;
	U0LCR=0x03;
}
void uart0_hex(int num)
{
	char s[20];
sprintf(s,"%x",num);
	uart0_string_tx(s);

}
void uart0_string_tx(char*s)
{
	while(*s)
	{
U0THR = *s;
while((U0LSR&(1<<5))==0);
    s++;
	}
}

