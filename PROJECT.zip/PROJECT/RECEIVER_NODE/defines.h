						//header.h/
#ifndef _HEADER_H
#define _HEADER_H
#define LCD_D 0xff

#define RS 1<<8

#define E 1<<9
#define TXB1 1<<5
#define TXREQ 1<<0


typedef unsigned int u32;
typedef unsigned char u8;

typedef struct CAN
{
u32 id;
u32 dlc;
u32	rtr;
u32 byteA;
u32 byteB;
}CAN2_MSG;
float f;
void CAN2_init(void);
void CAN2_TX1(CAN2_MSG);
void delay_ms(u32);
void CAN2_RX1(CAN2_MSG*);
void delay_mis(u32 mis);
void LCD_COMMAND(unsigned char cmd);
void LCD_INIT(void);
 void LCD_STR(unsigned char *p);
 void LCD_FLOAT(float f);
 void LCD_INTEGER(int n);

void LCD_DATA(unsigned char d);
#endif

