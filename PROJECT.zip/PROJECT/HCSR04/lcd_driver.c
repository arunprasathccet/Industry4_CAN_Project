#include<LPC21XX.H>

#define LCD_D 0xf<<20

#define RS 1<<17

#define RW 1<<18

#define EN 1<<19

void delay_ms(int );

void LCD_INIT(void);

void LCD_CMD(unsigned char);

void LCD_DATA(unsigned char);

void LCD_STR(unsigned char *);

void LCD_INTEGER(int);

void LCD_FLOAT(float);

 void delay_milliseconds(int ms);
void delay_milliseconds(int ms)

{

	T0PR=15000-1;

   T0TCR= 0X01;

   while(T0TC<ms);

T0TCR = 0x03;

T0TCR = 0x00;

}

void delay_ms(int ms)

{
	T0PR=15-1;

	T0TCR= 0X01;

	while(T0TC<ms);

	T0TCR = 0x03;
	T0TCR = 0x00;
}

void LCD_STR(unsigned char *s)

{
	char pos=0;
	while(*s)

{

  LCD_DATA(*s++);

  pos++;

  if(pos==16)

  LCD_CMD(0xc0);
 }

}

void LCD_INIT(void)

{

IODIR1 = LCD_D|RS|RW|EN;	//P0.0 to P0.9 as OUTPUT pins

LCD_CMD(0X01);//To clear the display

LCD_CMD(0X02);//Return cursor to home position

LCD_CMD(0X02);//Return cursor to home position

LCD_CMD(0X28);//4BIT INTERFACE MODE WITH BOTH LINES	

LCD_CMD(0X0C);//DISPLAY ON CURSOR OFF

LCD_CMD(0X80);//SELECT STARTING ADDRESS OF DDRAM

}

void LCD_CMD(unsigned char cmd)

{

IOCLR1 = LCD_D;

IOSET1 = (cmd&0xf0)<<16;//assigning command to the data pins

IOCLR1 = RS;//command register is selected

IOCLR1 = RW;

IOSET1 = EN;//latch the data to the LCD

delay_milliseconds(2);//wait for 2ms because LCD is in internal 

	                      // operation mode

IOCLR1 = EN;//To re-latch the next byte

IOCLR1 = LCD_D;

IOSET1 = (cmd&0x0F)<<20;//assigning command to the data pins

IOCLR1 = RS;//command register is selected

IOCLR1 = RW;	

IOSET1 = EN;//latch the data to the LCD

delay_milliseconds(2);//wait for 2ms because LCD is in internal 


	                      // operation mode

IOCLR1 = EN;//To re-latch the next byte

}

void LCD_DATA(unsigned char d)

{
IOCLR1 = LCD_D;

IOSET1 = (d&0xf0)<<16;//assigning command to the data pins

IOSET1 = RS;//data register is selected

IOCLR1 = RW;

IOSET1 = EN;//latch the data to the LCD

delay_milliseconds(2);//wait for 2ms because LCD is in internal 

	                      // operation mode

IOCLR1 = EN;//To re-latch the next byte

IOCLR1 = LCD_D;

IOSET1 = (d&0x0F)<<20;//assigning command to the data pins

IOSET1 = RS;//command register is selected

IOCLR1 = RW;

IOSET1 = EN;//latch the data to the LCD

delay_milliseconds(2);//wait for 2ms because LCD is in internal 


	                      // operation mode

IOCLR1 = EN;//To re-latch the next byte

}

void LCD_INTEGER(int n)

{

char arr[5];

int i=0;

if(n==0)

{

LCD_DATA('0');

}

else

{	

if(n<0)

{

LCD_DATA('-');

n=-n;

}

while(n>0)

{


		 arr[i++] = n%10;


		 n=n/10;


   }


	 for(i=i-1;i>=0;i--)


	   LCD_DATA(arr[i]+48);


  }


}


void LCD_FLOAT(float f)


{


 int temp;


 temp=f;


 LCD_INTEGER(temp);


 LCD_DATA('.');


 temp=(f-temp)*100;


 LCD_INTEGER(temp);	


}

