#include <lpc21xx.h>
#include "lcd_driver.c"
//#define MOTOR 1<<0
#define BUZ   1<<21
#define TRIG  1<<1
#define ECHO  1<<2
void ultra_init()
{
IODIR0|=(TRIG|BUZ);
IODIR0 &=~(ECHO);
IOCLR0|=(BUZ|TRIG);
}
int get_pulse()
{
int time;
while(!(IOPIN0&ECHO));
T0TCR=0x1;
while(IOPIN0&ECHO);
T0TCR=0x00;
time=T0TC;
T0TCR=0x2;
T0TCR=0x0;
 return time;
}

int main()
{
 unsigned int distance;
    const unsigned int tankHeight = 20;
    const unsigned int thresholdLevel = 5;
    unsigned int waterLevel;
   int pulse;
   LCD_INIT();
  ultra_init();
 while(1)
 {
	IOCLR0=TRIG;
	delay_ms(2);
	 IOSET0=TRIG;
	delay_ms(10);
	IOCLR0=TRIG;
	pulse=get_pulse();
	  distance = (pulse * 34) / (2 * 1000); 
  waterLevel = tankHeight - distance;
  LCD_CMD(0x80);
  LCD_STR("Ultrasonic");
  LCD_CMD(0xc0);
  LCD_INTEGER(waterLevel);
if(waterLevel < thresholdLevel)
            IOSET0 = BUZ;  
        else
            IOCLR0= BUZ; 
}
}
